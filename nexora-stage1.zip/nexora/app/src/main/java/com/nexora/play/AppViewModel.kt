package com.nexora.play

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.play.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val settings: StateFlow<Settings> = app.dataStore.data.map { it.toSettings() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Settings())

    private val _games = MutableStateFlow<List<Game>>(emptyList())
    val games = _games.asStateFlow()
    private val _scanning = MutableStateFlow(false)
    val scanning = _scanning.asStateFlow()

    private val _freeGames = MutableStateFlow<List<FreeGame>>(emptyList())
    val freeGames = _freeGames.asStateFlow()
    private val _downloads = MutableStateFlow<Map<String, DlState>>(emptyMap())
    val downloads = _downloads.asStateFlow()

    init {
        viewModelScope.launch {
            settings.map { it.romUri }.distinctUntilChanged().collect { rescan() }
        }
        viewModelScope.launch {
            _freeGames.value = withContext(Dispatchers.IO) { FreeGames.load(getApplication()) }
        }
    }

    private fun setDl(id: String, state: DlState) {
        _downloads.update { it + (id to state) }
    }

    fun download(g: FreeGame) {
        val tree = settings.value.romUri
        if (tree == null) {
            setDl(g.id, DlState.Failed("Choose your ROM folder in Library first."))
            return
        }
        if (_downloads.value[g.id] is DlState.Running) return
        setDl(g.id, DlState.Running(0L, -1L))
        viewModelScope.launch {
            var last = 0L
            try {
                FreeGames.download(getApplication(), g, Uri.parse(tree)) { done, total ->
                    val now = System.nanoTime()
                    if (now - last > 100_000_000L) {
                        last = now
                        setDl(g.id, DlState.Running(done, total))
                    }
                }
                setDl(g.id, DlState.Done)
                rescan()
            } catch (e: CancellationException) {
                throw e
            } catch (e: DownloadException) {
                setDl(g.id, DlState.Failed(e.message ?: "Download failed."))
            } catch (e: Exception) {
                setDl(g.id, DlState.Failed("Download failed: ${e.message ?: e.javaClass.simpleName}"))
            }
        }
    }

    fun rescan() {
        val uri = settings.value.romUri ?: run { _games.value = emptyList(); return }
        viewModelScope.launch {
            _scanning.value = true
            _games.value = withContext(Dispatchers.IO) {
                runCatching { RomScanner.scan(getApplication(), Uri.parse(uri)) }.getOrDefault(emptyList())
            }
            _scanning.value = false
        }
    }

    fun setRomFolder(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
        }
        save { it[Keys.ROM_URI] = uri.toString() }
    }

    fun setQuality(q: String) = save { it[Keys.QUALITY] = q }
    fun setFps(f: Int) = save { it[Keys.FPS] = f }
    fun setPadOpacity(v: Float) = save { it[Keys.PAD_OPACITY] = v }

    private fun save(block: (MutablePreferences) -> Unit) {
        viewModelScope.launch { getApplication<Application>().dataStore.edit { block(it) } }
    }
}
